package resources;

import java.util.ArrayList;
import java.util.List;

import dataCollection.*;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/get")
public class ListServerResource  {

    private static final long serialVersionUID = 1L;
    private List<dataCollection.MovieObject> list = new ArrayList<dataCollection.MovieObject>() ;;

    public ListServerResource() {

    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<dataCollection.MovieObject> doGet(@QueryParam("question") String question)   {

        NameParser n = new NameParser();
        if(question.equals("data")){
            System.out.println("Asked for Data Collection");
            n.getData();
            list = n.getMovielist() ;
        }

        else{
            System.out.println("Asked for list");

        }
        return list;
    }
}

