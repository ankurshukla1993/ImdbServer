import io.dropwizard.Application;
import io.dropwizard.Configuration;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import resources.ListServerResource;

public class MainApplication extends Application<MainConfiguration> {


    @Override
    public void initialize(Bootstrap<MainConfiguration> bootstrap) {

    }

    @Override
    public void run(MainConfiguration mainConfiguration, Environment environment) throws Exception {
        final ListServerResource listServerResource = new ListServerResource();
        environment.jersey().register(listServerResource);
    }

    public static void main(String[] args) throws Exception {
        new MainApplication().run(args);
    }

}
