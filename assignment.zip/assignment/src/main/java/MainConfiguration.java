import io.dropwizard.Configuration;

public class MainConfiguration extends Configuration {

}
